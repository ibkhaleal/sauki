const ARROW = 'Arrow';
export const ARROW_LEFT  = `${ ARROW }Left`;
export const ARROW_RIGHT = `${ ARROW }Right`;
export const ARROW_UP    = `${ ARROW }Up`;
export const ARROW_DOWN  = `${ ARROW }Down`;