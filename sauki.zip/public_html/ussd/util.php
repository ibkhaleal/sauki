<?php

class Util{
        static $GO_BACK = "98";        
        static $GO_TO_MAIN_MENU = "99";
        static $COUNTRY_CODE = "+234";        
    }

?>